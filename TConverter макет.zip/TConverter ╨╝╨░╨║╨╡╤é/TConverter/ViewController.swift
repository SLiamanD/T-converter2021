//
//  ViewController.swift
//  TConverter
//
//  Created by Алексей Грачев on 17.10.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var celsiusLabel: UILabel!
    @IBOutlet weak var fahrenheitLabel: UILabel!
    
    @IBOutlet weak var slider: UISlider!
    
    
    @IBAction func sliderChanged(_ sender: UISlider) {
    }
    
    

}

